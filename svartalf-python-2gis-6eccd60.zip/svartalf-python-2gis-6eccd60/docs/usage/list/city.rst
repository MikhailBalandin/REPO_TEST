Cities
========

Documentation: http://api.2gis.ru/doc/firms/list/city-list/

Allowed parameters:

 * where
 * project_id

Examples
----------

Searching by city name: ::

    api.city_list(where=u'Иркутск')

Searching by project id: ::

    api.city_list(project_id=11)
