Projects
==========

Documentation: http://api.2gis.ru/doc/firms/list/project-list/

No parameters is allowed.

Examples
---------

::

    api.project_list()
