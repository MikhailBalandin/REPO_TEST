Firm filials
===============

Documentation: http://api.2gis.ru/doc/firms/searches/firmsbyfilialid/

Allowed parameters:

 * firmid
 * page
 * pagesize

Examples
-----------

::

    api.firms_by_filial_id(firmid=1234567890)

::

    api.firms_by_filial_id(firmid=1234567890, page=2, pagesize=5)
