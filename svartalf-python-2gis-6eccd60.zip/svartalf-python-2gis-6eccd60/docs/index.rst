python-2gis
================================

**python-2gis** is a python (and pythonic) library for accessing the `2GIS API <http://api.2gis.ru>`_.


Contents
----------

.. toctree::
    :maxdepth: 2

    installation
    usage/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

